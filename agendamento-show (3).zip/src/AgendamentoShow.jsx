import { useState } from "react";
import "./AgendamentoShow.css";

export default function AgendamentoShow() {
  const [nome, setNome] = useState("");
  const [data, setData] = useState("");
  const [telefone, setTelefone] = useState("");
  const [email, setEmail] = useState("");
  const [localizacao, setLocalizacao] = useState("");

  const agendar = () => {
    if (nome && data && telefone && email && localizacao) {
      alert(`Agendamento confirmado para ${nome} em ${data} em ${localizacao}`);
      setNome("");
      setData("");
      setTelefone("");
      setEmail("");
      setLocalizacao("");
    } else {
      alert("Por favor, preencha todos os campos.");
    }
  };

  return (
    <div className="container">
      <h1>Agendar Michele e Geovani</h1>
      <img src="/capa-michele-geovani.png" alt="Capa Michele e Geovani" className="capa" />
      <input placeholder="Nome da pessoa" value={nome} onChange={(e) => setNome(e.target.value)} />
      <input type="date" value={data} onChange={(e) => setData(e.target.value)} />
      <input placeholder="Número de celular" value={telefone} onChange={(e) => setTelefone(e.target.value)} />
      <input placeholder="E-mail" value={email} onChange={(e) => setEmail(e.target.value)} />
      <input placeholder="Onde será o show?" value={localizacao} onChange={(e) => setLocalizacao(e.target.value)} />
      <button onClick={agendar}>Confirmar Agendamento</button>
    </div>
  );
}
